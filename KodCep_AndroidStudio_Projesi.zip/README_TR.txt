KodCep Android proje paketi

ÖNEMLİ: Bu ZIP doğrudan APK değildir; Android Studio'da APK üretmek için kaynak projedir.
Bu çalışma ortamında Android SDK/Gradle bulunmadığı için derlenmiş APK oluşturup doğrulayamıyorum.

APK oluşturma:
1. Bilgisayara Android Studio kur.
2. Android Studio > Open ile bu ZIP'ten çıkan KodCepAndroid klasörünü aç.
3. Gradle senkronizasyonunun tamamlanmasını bekle.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) seç.
5. Android Studio APK'nın konumunu gösterecek. Genellikle app/build/outputs/apk/debug/app-debug.apk olur.

Uygulama, KodCep web arayüzünü Android WebView içinde açar. Dosyaları tarayıcı depolamasına kaydetme davranışı uygulama verileriyle sınırlıdır. APK yüklemek için Android'de bilinmeyen uygulama yükleme izni gerekebilir.
